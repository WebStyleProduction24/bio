<?php

// Examples:
//  page_type:
//    - main,
//    - category,
//    - page,
//    - shop_category,
//    - product,
//    - brand,
//    - search

return [
    'main_slider' => [
        'name' => 'Слайдер в шапке',
        'width' => '1920',
        'height' => '459',
        'page_type' => 'main'
    ]
];